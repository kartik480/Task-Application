package pzn.project.ap.apptask

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.Typography
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import pzn.project.ap.apptask.ui.theme.AppTaskTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTaskTheme {
                AuthPanel()
            }
        }
    }
}
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF6200EE), // Example primary color
    secondary = Color(0xFF03DAC5), // Example secondary color
    background = Color.White, // White background
    surface = Color.White, // White surface
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black
)
private val AppTypography = Typography() // Default Material 3 Typography
@Composable
fun AppTaskTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = AppTypography, // Ensure Typography is defined or use Material3 defaults
        content = content
    )
}

@Composable
fun AuthPanel() {
    var isLogin by remember { mutableStateOf(true) }
    var isLoggedIn by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(),
            color = Color.White) {
        when {
            isLoggedIn -> LoggedInPanel()
            isLogin -> LoginScreen(
                onSwitchToRegister = { isLogin = false },
                onLoginSuccess = { isLoggedIn = true }
            )
            else -> RegisterScreen(onSwitchToLogin = { isLogin = true })
        }
    }
}

@Composable
fun LoginScreen(
    onSwitchToRegister: () -> Unit,
    onLoginSuccess: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Login", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Email") })
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Password") })
            Button(
                onClick = onLoginSuccess,
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("Login")
            }
            TextButton(onClick = onSwitchToRegister) {
                Text("Don't have an account? Register")
            }
        }
    }
}

@Composable
fun RegisterScreen(onSwitchToLogin: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Register", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Name") })
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Email") })
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Password") })
            Button(
                onClick = { /* Handle registration */ },
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("Register")
            }
            TextButton(onClick = onSwitchToLogin) {
                Text("Already have an account? Login")
            }
        }
    }
}

@Composable
fun LoggedInPanel() {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            // Blue header box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Color.Blue)

                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "xyz@gmail.com",
                    color = Color.White,
                    fontSize = 16.sp
                )
                Text(
                    text = "+91 99999999",
                    color = Color.White,
                    fontSize = 16.sp
                )
            }

            // Gray navigation box
            var menuExpanded by remember { mutableStateOf(false) }
            var loansExpanded by remember { mutableStateOf(false) }
            var salariesExpanded by remember { mutableStateOf(false) }
            var businessExpanded by remember { mutableStateOf(false) }
            var professionalsExpanded by remember { mutableStateOf(false) }

            // States to control sub-menu visibility
            var optionAExpanded by remember { mutableStateOf(false) }
            var optionBExpanded by remember { mutableStateOf(false) }
            var optionCExpanded by remember { mutableStateOf(false) }
            var optionDExpanded by remember { mutableStateOf(false) }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Color.LightGray)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left navigation items
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = "Icon",
                        tint = Color.DarkGray,
                        modifier = Modifier.size(20.dp)
                    )

                    // Loans dropdown
                    Box {
                        TextButton(
                            onClick = { loansExpanded = true },
                            modifier = Modifier.padding(0.dp)
                        ) {
                            Text("Loans", fontSize = 12.sp , color = Color.Black)
                        }
                        DropdownMenu(
                            expanded = loansExpanded,
                            onDismissRequest = { loansExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Personal Loan") },
                                onClick = { loansExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Home Loan") },
                                onClick = { loansExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Car Loan") },
                                onClick = { loansExpanded = false }
                            )
                        }
                    }

                    // Salaries dropdown
                    Box {
                        TextButton(
                            onClick = { salariesExpanded = true },
                            modifier = Modifier.padding(0.dp)
                        ) {
                            Text("Salaries", fontSize = 12.sp , color = Color.Black)
                        }
                        DropdownMenu(
                            expanded = salariesExpanded,
                            onDismissRequest = { salariesExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Salary Calculator") },
                                onClick = { salariesExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Tax Calculator") },
                                onClick = { salariesExpanded = false }
                            )
                        }
                    }

                    // Business dropdown
                    Box {
                        TextButton(
                            onClick = { businessExpanded = true },
                            modifier = Modifier.padding(0.dp)
                        ) {
                            Text("Business", fontSize = 12.sp , color = Color.Black)
                        }
                        DropdownMenu(
                            expanded = businessExpanded,
                            onDismissRequest = { businessExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Business Loans") },
                                onClick = { businessExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Business Plans") },
                                onClick = { businessExpanded = false }
                            )
                        }
                    }

                    // Professionals dropdown
                    Box {
                        TextButton(
                            onClick = { professionalsExpanded = true },
                            modifier = Modifier.padding(0.dp)
                        ) {
                            Text("Professionals", fontSize = 12.sp , color = Color.Black)
                        }
                        DropdownMenu(
                            expanded = professionalsExpanded,
                            onDismissRequest = { professionalsExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Find Professionals") },
                                onClick = { professionalsExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Professional Services") },
                                onClick = { professionalsExpanded = false }
                            )
                        }
                    }
                }

                // Right menu icon
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            Icons.Default.Menu,
                            contentDescription = "Menu",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        // Option A
                        DropdownMenuItem(
                            text = { Text("Option A") },
                            onClick = {
                                optionAExpanded = !optionAExpanded
                                optionBExpanded = false
                                optionCExpanded = false
                                optionDExpanded = false
                            }
                        )
                        if (optionAExpanded) {
                            DropdownMenuItem(
                                text = { Text("Sub-option A1") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                            DropdownMenuItem(
                                text = { Text("Sub-option A2") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                        }

                        // Option B
                        DropdownMenuItem(
                            text = { Text("Option B") },
                            onClick = {
                                optionBExpanded = !optionBExpanded
                                optionAExpanded = false
                                optionCExpanded = false
                                optionDExpanded = false
                            }
                        )
                        if (optionBExpanded) {
                            DropdownMenuItem(
                                text = { Text("Sub-option B1") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                            DropdownMenuItem(
                                text = { Text("Sub-option B2") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                            DropdownMenuItem(
                                text = { Text("Sub-option B3") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                        }

                        // Option C
                        DropdownMenuItem(
                            text = { Text("Option C") },
                            onClick = {
                                optionCExpanded = !optionCExpanded
                                optionAExpanded = false
                                optionBExpanded = false
                                optionDExpanded = false
                            }
                        )
                        if (optionCExpanded) {
                            DropdownMenuItem(
                                text = { Text("Sub-option C1") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                            DropdownMenuItem(
                                text = { Text("Sub-option C2") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                        }

                        // Option D
                        DropdownMenuItem(
                            text = { Text("Option D") },
                            onClick = {
                                optionDExpanded = !optionDExpanded
                                optionAExpanded = false
                                optionBExpanded = false
                                optionCExpanded = false
                            }
                        )
                        if (optionDExpanded) {
                            DropdownMenuItem(
                                text = { Text("Sub-option D1") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                            DropdownMenuItem(
                                text = { Text("Sub-option D2") },
                                onClick = { menuExpanded = false },
                                modifier = Modifier.padding(start = 16.dp)
                            )
                        }
                    }
                }
            }

            // Image Slider/Carousel
            ImageSlider()
        }

        item {
            // Special Offers Section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Special loan offers just for you!",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Vertical list of 8 offer images
                val offerImages = listOf(
                    R.drawable.offer1,
                    R.drawable.offer2,
                    R.drawable.offer3,
                    R.drawable.offer4,
                    R.drawable.offer5,
                    R.drawable.offer6,
                    R.drawable.offer7,
                    R.drawable.offer8
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    offerImages.forEach { imageRes ->
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = "Loan Offer",
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }
                }
            }
        }

        // Light blue box with stars and labels
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .background(Color(0xFFADD8E6).copy(alpha = 0.3f))
                        .padding(16.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "The solution is right here in front of you",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // First row of 3 icons with labels
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Credit",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Blue
                                )
                                Text("Credit", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Home Loan",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Red
                                )
                                Text("Home Loan", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Car",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Green
                                )
                                Text("Car", fontWeight = FontWeight.Bold)
                            }
                        }

                        // Second row of 3 icons with labels
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Mortgage",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Magenta
                                )
                                Text("Mortgage", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Edu",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Yellow
                                )
                                Text("Edu", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Credit Score",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Cyan
                                )
                                Text("Credit Score", fontWeight = FontWeight.Bold)
                            }
                        }

                        // Third row of 2 icons with labels
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "IFSC",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.Black
                                )
                                Text("IFSC", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Calc",
                                    modifier = Modifier.size(48.dp),
                                    tint = Color.DarkGray
                                )
                                Text("Calc", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Light pink box with image and bold points
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFFC0CB).copy(alpha = 0.3f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Medium sized image
                        Image(
                            painter = painterResource(id = R.drawable.offer8),
                            contentDescription = "Financial Solutions",
                            modifier = Modifier
                                .size(200.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )

                        // Points list with bold key phrases
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                buildAnnotatedString {
                                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                                        append("Comprehensive Financial Solutions")
                                    }
                                    append(": Offers a variety of loans, credit cards, and insurance products tailored to diverse needs.")
                                },
                                fontSize = 14.sp
                            )
                            Text(
                                buildAnnotatedString {
                                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                                        append("Competitive Rates")
                                    }
                                    append(": Provides attractive interest rates on loans and low APRs for credit cards.")
                                },
                                fontSize = 14.sp
                            )
                            Text(
                                buildAnnotatedString {
                                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                                        append("Flexible Terms")
                                    }
                                    append(": Features customizable repayment plans for loans and flexible credit card options.")
                                },
                                fontSize = 14.sp
                            )
                            Text(
                                buildAnnotatedString {
                                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                                        append("Insurance Coverage")
                                    }
                                    append(": Includes various insurance products to protect against unforeseen events.")
                                },
                                fontSize = 14.sp
                            )
                            Text(
                                buildAnnotatedString {
                                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                                        append("Streamlined Application Process")
                                    }
                                    append(": Facilitates quick and easy applications for loans, credit cards, and insurance.")
                                },
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Dark grey section with square frames
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.DarkGray)
                    .padding(16.dp)
            ) {
                Text(
                    text = "Our Services",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    textAlign = TextAlign.Center
                )

                // First row of 2 square frames
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SquareFrame("Personal Loans", R.drawable.offer1)
                    SquareFrame("Home Loans", R.drawable.offer2)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Second row of 2 square frames
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SquareFrame("Car Loans", R.drawable.offer3)
                    SquareFrame("Education Loans", R.drawable.offer4)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Third row of 2 square frames
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SquareFrame("Business Loans", R.drawable.offer5)
                    SquareFrame("Credit Cards", R.drawable.offer6)
                }
            }
        }

        // New light pink section with horizontally scrolling images
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFC0CB).copy(alpha = 0.3f))
                    .padding(vertical = 16.dp)
            ) {
                // Title for top scrolling images
                Text(
                    text = "Featured Partners",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                // Top row - auto-scrolling right
                AutoScrollingRow()

                Spacer(modifier = Modifier.height(24.dp))

                // Title for bottom scrolling images
                Text(
                    text = "Our Sponsors",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                // Bottom row - auto-scrolling right
                AutoScrollingRow()
            }
        }

        // New dark blue section with "Our Services," "About Us," and "Contact Us"
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF00008B)) // Dark blue background
                    .padding(16.dp)
            ) {
                // Our Services Section
                Text(
                    text = "Our Services",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "We offer a wide range of financial products including personal loans, home loans, car loans, education loans, business loans, and credit cards. Our services are designed to meet your financial needs with competitive rates and flexible terms.",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // About Us Section
                Text(
                    text = "About Us",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "We are a leading financial services provider committed to helping individuals and businesses achieve their financial goals. With years of experience and a customer-centric approach, we strive to deliver innovative and reliable solutions.",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Contact Us Section
                Text(
                    text = "Contact Us",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Have questions? Reach out to us!\n" +
                            "Email: support@financialservices.com\n" +
                            "Phone: +91 9876543210\n" +
                            "Address: 123 Financial Street, Business City, India",
                    color = Color.White,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun AutoScrollingRow() {
    val imageList = listOf(
        Pair("Partner 1", R.drawable.offer1),
        Pair("Partner 2", R.drawable.offer2),
        Pair("Partner 3", R.drawable.offer3),
        Pair("Partner 4", R.drawable.offer4),
        Pair("Partner 5", R.drawable.offer5),
        Pair("Partner 6", R.drawable.offer6)
    )

    // Create an extended list for seamless looping
    val extendedList = List(4) { imageList }.flatten()

    // Animation for continuous scrolling to the right
    val infiniteTransition = rememberInfiniteTransition()
    val scrollOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -1500f, // Negative value to scroll right
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .background(Color(0xFFFFC0CB).copy(alpha = 0.3f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .offset(x = scrollOffset.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                // Display original list + extended list for looping effect
                (imageList + extendedList).forEach { pair ->
                    SquareFrame(
                        title = pair.first,
                        imageRes = pair.second
                    )
                }
            }
        }
    }
}

@Composable
fun SquareFrame(title: String, imageRes: Int) {
    Box(
        modifier = Modifier
            .size(150.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = title,
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun ImageSlider() {
    val imageResources = listOf(
        R.drawable.one,
        R.drawable.two,
        R.drawable.three,
        R.drawable.four,
        R.drawable.five
    )

    var currentIndex by remember { mutableStateOf(0) }

    LaunchedEffect(currentIndex) {
        delay(2000)
        currentIndex = (currentIndex + 1) % imageResources.size
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .padding(16.dp)
    ) {
        // Main image
        Image(
            painter = painterResource(id = imageResources[currentIndex]),
            contentDescription = "Slider Image $currentIndex",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(8.dp))
        )

        // Left arrow
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .clickable {
                    currentIndex = if (currentIndex - 1 >= 0) currentIndex - 1 else imageResources.size - 1
                }
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(50))
                .size(40.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "<",
                color = Color.White,
                fontSize = 24.sp
            )
        }

        // Right arrow
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .clickable {
                    currentIndex = (currentIndex + 1) % imageResources.size
                }
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(50))
                .size(40.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = ">",
                color = Color.White,
                fontSize = 24.sp
            )
        }

        // Indicator dots at the bottom
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            repeat(imageResources.size) { index ->
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = if (index == currentIndex) Color.White else Color.White.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(50)
                        )
                )
            }
        }
    }
}